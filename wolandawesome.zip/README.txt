place revelations folder & rc.lua in .config/awesome
place polybar folder in .config/

change the bottom line of rc.lua to suit your need
